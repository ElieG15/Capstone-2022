﻿using InventoryAPI.Helpers;
using InventoryAPI.Models;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

namespace InventoryAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ContainersController : ControllerBase
    {
        private readonly ILogger<ContainersController> _logger;

        public ContainersController(ILogger<ContainersController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetContainers")]
        public IActionResult Get()
        {
            List<Container> ContainerList = new List<Container>();
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            string sql = "SELECT * FROM container";
            using var cmd = new MySqlCommand(sql, conn);

            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Container container = new Container(rdr);
                ContainerList.Add(container);
            }

            conn.Close();
            return Ok(ContainerList);
        }
        
        [HttpGet("{id}")] //get specifc container by id
        public IActionResult Get(string id)
        {
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            string sql = "SELECT * FROM Container WHERE containerid=@containerid";
            using var cmd = new MySqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@containerid", id);
            cmd.Prepare();
            MySqlDataReader rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                Container foundContainer = new Container(rdr);
                return Ok(foundContainer);
            }

            conn.Close();
            return Ok(false);

        }// end get by ID

        [HttpPost]
        public IActionResult Post([FromBody] Container newRecord)
        {
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var sql = "INSERT INTO item Container " +
                "(@ContainerID, @Name, @Description, @Tags, @AssignedLocation, " +
                "@CurrentLocation, @Image)";

            var cmd = new MySqlCommand(sql, conn);

            newRecord.ContainerID = "I" + Random.Shared.NextInt64(10000).ToString();

            cmd.Parameters.AddWithValue("@ContainerID", newRecord.ContainerID);
            cmd.Parameters.AddWithValue("@Name", newRecord.Name);
            cmd.Parameters.AddWithValue("@Description", newRecord.Description);
            cmd.Parameters.AddWithValue("@Tags", newRecord.Tags);
            cmd.Parameters.AddWithValue("@AssignedLocation", newRecord.AssignedLocation);
            cmd.Parameters.AddWithValue("@Image", newRecord.Image);

            cmd.Prepare();

            cmd.ExecuteNonQuery();

            return Ok(newRecord);
        }


    }
}

