﻿using InventoryAPI.Helpers;
using InventoryAPI.Models;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

namespace InventoryAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ItemsController : ControllerBase
    {
        private readonly ILogger<ItemsController> _logger;

        public ItemsController(ILogger<ItemsController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetItems")]
        public IActionResult Get()
        {
            List<Item> items = new List<Item>();
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            string sql = "SELECT * FROM Item";
            using var cmd = new MySqlCommand(sql, conn);

            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Item item = new Item(rdr);
                items.Add(item);
            }

            conn.Close();
            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            string sql = "SELECT * FROM Item WHERE ItemID=@ItemID";
            using var cmd = new MySqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@ItemID", id);
            cmd.Prepare();
            MySqlDataReader rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                Item item = new Item(rdr);
                return Ok(item);
            }

            conn.Close();
            return Ok(false);

        }

        [HttpGet("search/{text}")] //search
        public async Task<IActionResult> GetSearchAsync(string text)
        {
            List<Item> items = new List<Item>();
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            string sql = "SELECT * FROM item WHERE MATCH(Name, Description, Tags) AGAINST(@text);";
            using var cmd = new MySqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@text", text);
            cmd.Prepare();
            MySqlDataReader rdr = (MySqlDataReader)await cmd.ExecuteReaderAsync();

            while(rdr.Read())
            {
                Item item = new Item(rdr);
                items.Add(item);
            }

            //conn.Close();
            
            return Ok(items);

        }

        [HttpPost]
        public IActionResult Post([FromBody] Item newRecord)
        {
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var sql = "INSERT INTO item VALUES " +
                "(@ItemID, @Name, @Description, @Tags, @AssignedLocation, " + 
                "@CurrentLocation, @CurrentUser, @Quantity, @UnitWeight, @Image)";

            var cmd = new MySqlCommand(sql, conn);

            newRecord.ItemID = "I" + Random.Shared.NextInt64(10000).ToString();

            cmd.Parameters.AddWithValue("@ItemID", newRecord.ItemID);
            cmd.Parameters.AddWithValue("@Name", newRecord.Name);
            cmd.Parameters.AddWithValue("@Description", newRecord.Description);
            cmd.Parameters.AddWithValue("@Tags", newRecord.Tags);
            cmd.Parameters.AddWithValue("@AssignedLocation", newRecord.AssignedLocation);
            cmd.Parameters.AddWithValue("@CurrentLocation", newRecord.CurrentLocation);
            cmd.Parameters.AddWithValue("@CurrentUser", newRecord.CurrentUser);
            cmd.Parameters.AddWithValue("@Quantity", newRecord.Quantity);
            cmd.Parameters.AddWithValue("@UnitWeight", newRecord.UnitWeight);
            cmd.Parameters.AddWithValue("@Image", newRecord.Image);

            cmd.Prepare();

            cmd.ExecuteNonQuery();

            return Ok(newRecord);
        }

        [HttpPut("{id}")]
        public IActionResult Put(string id, [FromBody] Item updatedRecord)
        {
            string connectionString = DBUtil.Connectionstring();
            Item item = new Item();
            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var sql = "UPDATE item SET " +
            "Name=@Name," +
                            "Description=@Description," +
                            "Tags=@Tags," +
                            "AssignedLocation=@AssignedLocation," +
                            "CurrentLocation=@CurrentLocation," +
                            "CurrentUser=@CurrentUser," +
                            "Quantity=@Quantity," +
                            "UnitWeight=@UnitWeight," +
                            "Image=@Image" +
            " WHERE ItemID=@ItemID";

            var updateCMD = new MySqlCommand(sql, conn);
            updateCMD.Parameters.AddWithValue("@Name", updatedRecord.Name);
            updateCMD.Parameters.AddWithValue("@Description", updatedRecord.Description);
            updateCMD.Parameters.AddWithValue("@Tags", updatedRecord.Tags);
            updateCMD.Parameters.AddWithValue("@AssignedLocation", updatedRecord.AssignedLocation);
            updateCMD.Parameters.AddWithValue("@CurrentLocation", updatedRecord.CurrentLocation);
            updateCMD.Parameters.AddWithValue("@CurrentUser", updatedRecord.CurrentUser);
            updateCMD.Parameters.AddWithValue("@Quantity", updatedRecord.Quantity);
            updateCMD.Parameters.AddWithValue("@UnitWeight", updatedRecord.UnitWeight);
            updateCMD.Parameters.AddWithValue("@Image", updatedRecord.Image);
            updateCMD.Parameters.AddWithValue("@ItemID", id);
                
            updateCMD.Prepare();
            updateCMD.ExecuteNonQuery();

            return Ok(true);

            return Ok(false);
            
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            string connectionString = DBUtil.Connectionstring();

            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            var sql = "DELETE FROM item WHERE ItemID=@ItemID";

            using var cmd = new MySqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@ItemID", id);

            cmd.Prepare();

            cmd.ExecuteNonQuery();

            return Ok(true);
        }
    }
}