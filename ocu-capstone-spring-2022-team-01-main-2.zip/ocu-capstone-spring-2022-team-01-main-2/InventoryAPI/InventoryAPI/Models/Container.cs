﻿using MySql.Data.MySqlClient;

namespace InventoryAPI.Models
{
    public class Container
    {
        public string ContainerID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Tags { get; set; }
        public string AssignedLocation { get; set; }
        public string Image { get; set; }

        public Container() { }

        public Container(MySqlDataReader rdr)
        {
            ContainerID = rdr.GetString("ContainerID");
            Name = rdr.GetString("Name");
            Description = rdr.GetString("Description");
            Tags = rdr.GetString("Tags");
            AssignedLocation = rdr.GetString("AssignedLocation");
            Image = rdr.GetString("Image");
        }
    }
}
