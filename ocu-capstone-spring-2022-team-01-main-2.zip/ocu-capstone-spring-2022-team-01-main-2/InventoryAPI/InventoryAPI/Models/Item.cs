﻿using MySql.Data.MySqlClient;

namespace InventoryAPI.Models
{
    public class Item
    {
        public string? ItemID { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Tags { get; set; }
        public string? AssignedLocation { get; set; }
        public string? CurrentLocation { get; set; }
        public string? CurrentUser { get; set; }
        public int? Quantity { get; set; }
        public int? UnitWeight { get; set; }
        public string? Image { get; set; }

        public Item() { }

        public Item(MySqlDataReader rdr)
        {
            ItemID = rdr.GetString("ItemID");
            Name = rdr.GetString("Name");
            Description = rdr.GetString("Description");
            Tags = rdr.GetString("Tags");
            AssignedLocation = rdr.GetString("AssignedLocation");
            CurrentLocation = rdr.GetString("CurrentLocation");
            CurrentUser = rdr.GetString("CurrentUser");
            Quantity = rdr.GetInt32("Quantity");
            UnitWeight = rdr.GetInt32("UnitWeight");
            Image = rdr.GetString("Image");
        }
    }
}
