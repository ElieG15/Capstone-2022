//
//  ContainerDetailsController.swift
//  Organizer
//
//  Created by Justin Mabray on 4/23/22.
//

//import Foundation

import UIKit

class ContainerDetailsController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return ContainersFromDB.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return ContainersFromDB[row].containerID + " " + ContainersFromDB[row].name
    }
    
    
    
    struct ContainerStruct: Codable{
        var containerID: String
        var name: String
        var description: String
        var tags: String
        var assignedLocation: String
        var image: String
    }
    
    //Vars
    var lookupID: String = "" //the ContainerID to be requested
    var ContainersFromDB: [ContainerStruct] = [] //list of all containers to populate the picker
    
    //UI outlets
    @IBOutlet weak var NameTextBox: UITextField!
    @IBOutlet weak var DescriptionTextBox: UITextField!
    @IBOutlet weak var TagsTextBox: UITextField!
    @IBOutlet weak var ContainerPicker: UIPickerView!
    
    @IBAction func EditButton(_ sender: Any) {
        self.NameTextBox.isUserInteractionEnabled = true
        self.DescriptionTextBox.isUserInteractionEnabled = true
        self.TagsTextBox.isUserInteractionEnabled = true;
        self.ContainerPicker.isUserInteractionEnabled = true
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Startup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        Startup()
    }
    
    func Startup()
    {
        GetContainers { (ContainerStruct) in
            self.ContainersFromDB = ContainerStruct
            print(self.ContainersFromDB[0].containerID)
            
            self.ContainerPicker.delegate = self;
            self.ContainerPicker.dataSource = self;
        }
        
        getContainerByID { (ContainerStruct) in
            var record = ContainerStruct
            self.NameTextBox.text = record.name
            self.NameTextBox.isUserInteractionEnabled = false
            self.DescriptionTextBox.text = record.description
            self.DescriptionTextBox.isUserInteractionEnabled = false
            self.TagsTextBox.text = record.tags
            self.TagsTextBox.isUserInteractionEnabled = false
            //self.ContainerText.text = record.currentLocation
            //self.ContainerText.isUserInteractionEnabled = false
            
            for (C, DBContainer) in self.ContainersFromDB.enumerated() {
                if DBContainer.containerID == record.assignedLocation{
                    self.ContainerPicker.selectRow(C, inComponent: 0, animated: false)
                }
            }
            
            
        }
        
        
    }
    
    
    
    func GetContainers(completion: @escaping ([ContainerStruct]) -> ()){
        print("getAllcontainers started")
        guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/containers") else{
            print("bad url")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask =
        session.dataTask(with:url){ [self]
            (data, response, error) in
            
            guard error == nil else{
                print(error?.localizedDescription)
                return
            }
            guard let data = data else{
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try
                    decoder.decode([ContainerStruct].self, from: data)
                
                
                
                ContainersFromDB = decodedData
                
                if ContainersFromDB.count == 0{
                    print("no items, dont load them")
                    return
                }
                
                print(ContainersFromDB[0].containerID)
                print(decodedData[0].containerID)
                
                DispatchQueue.main.async{
                    completion(decodedData)
                }
                
            } catch { print(error.localizedDescription)}
            
        }
        dataTask.resume()
        
        
    }//end GetContainers
    
    func getContainerByID(completion: @escaping (ContainerStruct) -> ()){
        guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/containers/\(lookupID)") else{
            print("information not available")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask =
        session.dataTask(with:url){ [self]
            (data, response, error) in
            
            guard error == nil else{
                print(error?.localizedDescription)
                return
            }
            guard let data = data else{
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try
                    decoder.decode(ContainerStruct.self, from: data)
                
                DispatchQueue.main.async{
                    completion(decodedData)
                }
                
            } catch { print(error.localizedDescription)}
            
        }
        dataTask.resume()
        
    }//end GetContainerByID
    
    
    
    

}

