//
//  CreateViewController.swift
//  Organizer
//
//  Created by Justin Mabray on 3/1/22.
//

import UIKit

class CreateViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return DropdownList.count
    }
    
    // The data to return fopr the row and component (column) that's being passed in
      //func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -&gt; String? {
      //    return DropdownList[row].name
     // }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return DropdownList[row].containerID + " " + DropdownList[row].name
    }
    
    struct ContainerStruct: Codable{
        var containerID: String
        var name: String
        var description: String
        var tags: String
        var assignedLocation: String
        var image: String
    }
    @IBOutlet weak var ItemContainerSelect: UIPickerView!
    @IBOutlet weak var ContainerContainerSelect: UIPickerView!
    
    override func viewWillAppear(_ animated: Bool) {
        GetContainers { (ItemStructs) in
            self.DropdownList = ItemStructs
            print(self.DropdownList[0].containerID)
            
            // Connect data:
            self.ItemContainerSelect.delegate = self
            self.ItemContainerSelect.dataSource = self
            
            self.ContainerContainerSelect.delegate = self
            self.ContainerContainerSelect.dataSource = self
            
            //ItemContainerSelect.dataSource =
            //self.SearchResults.reloadData()
        }
    }
    
    var DropdownList: [ContainerStruct] = [] //used to populate container dropdown

    
    @IBOutlet weak var SelectedType: UISegmentedControl!
    @IBOutlet weak var ItemMenu: UIStackView!
    @IBOutlet weak var ContainerMenu: UIStackView!
    
    
    
    @IBAction func CreateClicked(_ sender: Any) {
        let toggle = SelectedType.selectedSegmentIndex
        print (toggle)
        
        if toggle==0 {
            CreateItem()
        }
        else if toggle == 1{
            CreateContainer()
        }
    }
    
    
    func CreateItem() {
        print(ItemName.text!);
        print("new item quanity should be" + (ItemQuantity.text ?? "its null"))
        let json: [String: Any] = [
            "itemID": "I1234",
            "name": ItemName.text!,
            "description": ItemDescription.text!,
            "unitWeight": Int(ItemWeight.text!) ?? 0,
            "quantity": Int(ItemQuantity.text!) ?? 0,
            "tags": ItemTag.text!,
            "assignedLocation": DropdownList[ItemContainerSelect.selectedRow(inComponent:0)].containerID,
            //"assignedLocation": ItemContainer.text!,
            "currentLocation": "1",
            "currentUser": "test",
            "image": "test"
        ]
        
        let valid = JSONSerialization.isValidJSONObject(json)
        print(valid)
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)

        let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/items")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

       request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
       request.setValue("application/json", forHTTPHeaderField: "Content-Type")
       
       request.httpBody = jsonData

       let task = URLSession.shared.dataTask(with: request) { data, response, error in
           guard let data = data, error == nil else {
               print(error?.localizedDescription ?? "No data")
               return
           }
           let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
           if let responseJSON = responseJSON as? [String: Any] {
               print(responseJSON)
               
               self.showToast(message: "Saved", seconds: 3)
           }
       }

       task.resume()

    }// end createitem
    
    
    func CreateContainer() {
        print(ItemName.text!);
        let json: [String: Any] = [
            "ContainerID": "I1234",
            "name": ContainerName.text!,
            "description": ContainerDesctipion.text!,
            "assignedLocation": DropdownList[ContainerContainerSelect.selectedRow(inComponent:0)].containerID,
        ]
        
        let valid = JSONSerialization.isValidJSONObject(json)
        print(valid)
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)

        let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/containers")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

       request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
       request.setValue("application/json", forHTTPHeaderField: "Content-Type")
       
       request.httpBody = jsonData

       let task = URLSession.shared.dataTask(with: request) { data, response, error in
           guard let data = data, error == nil else {
               print(error?.localizedDescription ?? "No data")
               return
           }
           let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
           if let responseJSON = responseJSON as? [String: Any] {
               print(responseJSON)
               
               self.showToast(message: "Saved", seconds: 3)
           }
       }

       task.resume()

    }// end createcontainer
    
    func showToast(message: String, seconds: Double) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.view.backgroundColor = UIColor.green
            alert.view.alpha = 0.6
            alert.view.layer.cornerRadius = 15
            
            self.present(alert, animated: true)
            alert.dismiss(animated: true)
        }
    }
    
    @IBOutlet weak var ItemWeight: UITextField!
    @IBOutlet weak var ItemQuantity: UITextField!
    @IBOutlet weak var ItemContainer: UITextField!
    @IBOutlet weak var ItemTag: UITextField!
    @IBOutlet weak var ItemName: UITextField!
    
    @IBOutlet weak var ContainerName: UITextField!
    @IBOutlet weak var ContainerDesctipion: UITextField!
    @IBOutlet weak var ContainerTags: UITextField!
    @IBOutlet weak var ContainerLocation: UITextField!
    
    
    
    @IBAction func TestButton(_ sender: Any)
    {
        print("testbutton")
    }
    @IBOutlet weak var ItemDescription: UITextField!
    
    @IBAction func EntryTypeSwitch(_ sender: Any) {
        // this function is called by the switch at the top. it toggles the UI between creating an item or a container
        let toggle = SelectedType.selectedSegmentIndex
        print (toggle)
        
        if toggle==0 {
            ItemMenu.isHidden = false
            ContainerMenu.isHidden = true
        }
        else if toggle == 1{
            ItemMenu.isHidden = true
            ContainerMenu.isHidden = false
        }
    }
    
    
    func GetContainers(completion: @escaping ([ContainerStruct]) -> ()){
        print("getAllItems started")
        guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/containers") else{
            print("bad url")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask =
        session.dataTask(with:url){ [self]
            (data, response, error) in
            
            guard error == nil else{
                print(error?.localizedDescription)
                return
            }
            guard let data = data else{
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try
                    decoder.decode([ContainerStruct].self, from: data)
                
                
                
                DropdownList = decodedData
                
                if DropdownList.count == 0{
                    print("no items, dont load them")
                    return
                }
                
                print(DropdownList[0].containerID)
                print(decodedData[0].containerID)
                
                DispatchQueue.main.async{
                    completion(decodedData)
                }
                
            } catch { print(error.localizedDescription)}
            
        }
        dataTask.resume()
        
        
    }
    
    
}
