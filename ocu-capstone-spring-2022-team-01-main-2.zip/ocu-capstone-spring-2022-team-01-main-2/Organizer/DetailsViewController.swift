//
//  DetailsViewController.swift
//  Organizer
//
//  Created by Justin Mabray on 3/1/22.
//

import UIKit

class DetailsViewController: UIViewController{
    
    var currentId: String = ""
    
    
    struct ItemStruct: Codable{
        var itemID: String
        var name: String
        var description: String
        var tags: String
        var assignedLocation: String
        var currentLocation: String
        var currentUser: String
        var quantity: Int
        var unitWeight: Int
        var image: String
    }
     
        func getItemsDescription(completion: @escaping (ItemStruct) -> ()){
            guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/items/\(currentId)") else{
                print("information not available")
                return
            }
            
            let session = URLSession.shared
            
            let dataTask =
            session.dataTask(with:url){ [self]
                (data, response, error) in
                
                guard error == nil else{
                    print(error?.localizedDescription)
                    return
                }
                guard let data = data else{
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    
                    let decodedData = try
                        decoder.decode(ItemStruct.self, from: data)
                    
                    DispatchQueue.main.async{
                        completion(decodedData)
                    }
                    
                } catch { print(error.localizedDescription)}
                
            }
            dataTask.resume()
            
        }//end GetAllItems
    
    @IBAction func UpdateButton(_ sender: Any) {
        
        UpdateItem()
    }
    
    
    
    
    func showToast(message: String, seconds: Double) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.view.backgroundColor = UIColor.green
            alert.view.alpha = 0.6
            alert.view.layer.cornerRadius = 15
            
            self.present(alert, animated: true)
            alert.dismiss(animated: true)
        }
    }
    
    func UpdateItem() {
        let json: [String: Any] = [
            "itemID": currentId,
            "name": NameText.text!,
            "description": DescriptionText.text!,
            "unitWeight": Int(WeightText.text!) ?? 0,
            "quantity": Int(QuantityText.text!) ?? 0,
            "tags": TagsText.text!,
            "assignedLocation": ContainerText.text ?? "1",
            "currentLocation": "1",
            "currentUser": "test",
            "image": "test"
        ]
        
        let valid = JSONSerialization.isValidJSONObject(json)
        print(valid)
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)

        let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/items/\(currentId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"

       request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
       request.setValue("application/json", forHTTPHeaderField: "Content-Type")
       
       request.httpBody = jsonData

       let task = URLSession.shared.dataTask(with: request) { data, response, error in
           guard let data = data, error == nil else {
               print(error?.localizedDescription ?? "No data")
               return
           }
           let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
           if let responseJSON = responseJSON as? [String: Any] {
               print(responseJSON)
               
               self.showToast(message: "Saved", seconds: 3)
           }
       }

       task.resume()

    }// end createitem
   

    override func viewDidLoad() {
        
        super.viewDidLoad()
        getItemsDescription { (ItemStruct) in
            var record = ItemStruct
            self.NameText.text = record.name
            self.NameText.isUserInteractionEnabled = false
            self.DescriptionText.text = record.description
            self.DescriptionText.isUserInteractionEnabled = false
            self.TagsText.text = record.tags
            self.TagsText.isUserInteractionEnabled = false
            self.ContainerText.text = record.currentLocation
            self.ContainerText.isUserInteractionEnabled = false
            self.QuantityText.text = String (record.quantity)
            self.ContainerText.isUserInteractionEnabled = false
            self.WeightText.text = String (record.unitWeight)
            self.WeightText.isUserInteractionEnabled = false
        }
        
        
        
    }
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is CreateViewController {
            let info = segue.destination as? CreateViewController
            
            
            
            
            //info?.currentId = DataForTable[selectedRow].itemID
    }
     */
    
    
    
    
    @IBOutlet weak var NameText: UITextField!
    @IBOutlet weak var DescriptionText: UITextField!
    @IBOutlet weak var TagsText: UITextField!
    @IBOutlet weak var ContainerText: UITextField!
    @IBOutlet weak var QuantityText: UITextField!
    @IBOutlet weak var WeightText: UITextField!
    
    func EditEntry(){
        
    }
    
    
    @IBAction func EditButton(_ sender: Any) {
        self.NameText.isUserInteractionEnabled = true
        self.DescriptionText.isUserInteractionEnabled = true
        self.TagsText.isUserInteractionEnabled = true
        self.ContainerText.isUserInteractionEnabled = true
        self.ContainerText.isUserInteractionEnabled = true
        self.WeightText.isUserInteractionEnabled = true
    }
    

    
    
    
    
    
    

    
    

    
    
}


