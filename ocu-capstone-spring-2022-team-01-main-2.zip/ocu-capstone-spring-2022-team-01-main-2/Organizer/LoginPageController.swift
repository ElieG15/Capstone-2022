//
//  LoginPageController.swift
//  Organizer
//
//  Created by Justin Mabray on 4/16/22.
//

import Foundation
import UIKit

class LoginPageController : UIViewController{
    @IBOutlet weak var NameField: UITextField!
    @IBOutlet weak var PasswordField: UITextField!
    
    @IBAction func LoginPressed(_ sender: Any) {
        CheckLogin()
    }
    
    func CheckLogin(){
        ChangeViews()
    }
    
    func ChangeViews(){
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "TabController")
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        // ah, of course. the first thing that finally gets this to work is depreciated.
        
    }
}
