//
//  SearchTableViewCell.swift
//  Organizer
//
//  Created by Justin Mabray on 4/7/22.
//

import UIKit

protocol SearchTableViewCellDelegate: AnyObject{
    func didTapButton(with title: String)
}

class SearchTableViewCell: UITableViewCell {
    
    weak var delegate: SearchTableViewCellDelegate?
    
    static let identifier = "SearchTableViewCell"
    
    static func nib() -> UINib{
        return UINib(nibName: "SearchTableViewCell", bundle: nil)
    }
    
    @IBOutlet var button: UIButton!
    private var title: String = ""
    
    @IBAction func didTapButton(){
        delegate?.didTapButton(with: title)
    }
    
    func configure(with title: String){
        self.title = title
        //button.setTitle(title, for: .normal)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        //button.setTitleColor(.link, for: .normal)
        // Initialization code
    }

    
    
}
