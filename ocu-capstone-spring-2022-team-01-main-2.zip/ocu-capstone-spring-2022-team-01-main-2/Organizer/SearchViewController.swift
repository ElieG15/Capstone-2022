//
//  ViewController.swift
//  Organizer
//
//  Created by Justin Mabray on 2/27/22.
//

import UIKit

class SearchViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var SelectedType: UISegmentedControl!
    @IBOutlet weak var ContainerResults: UITableView!
    
    var Typetoggle = 0;
    @IBAction func EntryTypeSwitch(_ sender: Any) {
        // this function is called by the switch at the top. it toggles the UI between creating an item or a container
        Typetoggle = SelectedType.selectedSegmentIndex
        print (Typetoggle)
        self.SearchResults.reloadData()
        if Typetoggle==0 {
            //SearchResults.isHidden = false
            //ContainerResults.isHidden = true
        }
        else if Typetoggle == 1{
            //SearchResults.isHidden = true
            //ContainerResults.isHidden = false
        }
    }

    var selectedRow = 0
    
    struct ItemStruct: Codable{
        var itemID: String
        var name: String
        var description: String
        var tags: String
        var assignedLocation: String
        var currentLocation: String
        var currentUser: String
        var quantity: Int
        var unitWeight: Int
        var image: String
    }
    
    struct ContainerStruct: Codable{
        var containerID: String
        var name: String
        var description: String
        var tags: String
        var assignedLocation: String
        var image: String
    }
    
    
    var ContainersFromDB: [ContainerStruct] = []
    var ItemsFromDB: [ItemStruct] = []
    
    @IBOutlet weak var SearchResults: UITableView!
    
    @IBOutlet weak var SearchTextBox: UITextField!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(Typetoggle == 0){
            return ItemsFromDB.count}
        else{
            return ContainersFromDB.count}
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        print("tableView")
        let cell = tableView.dequeueReusableCell(withIdentifier: SearchTableViewCell.identifier, for: indexPath) as! SearchTableViewCell
        
        if(Typetoggle == 0){
        cell.configure(with: ItemsFromDB[indexPath.row].itemID)
        cell.textLabel?.text = ItemsFromDB[indexPath.row].name
        cell.detailTextLabel?.text = ItemsFromDB[indexPath.row].description
        }
        else{
            cell.configure(with: ContainersFromDB[indexPath.row].containerID)
            cell.textLabel?.text = ContainersFromDB[indexPath.row].name
            cell.detailTextLabel?.text = ContainersFromDB[indexPath.row].description
        }
        
        cell.accessoryType = .disclosureIndicator
        
        cell.delegate = self
        print(indexPath.row)
        
        return cell

        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedRow = indexPath.row
        if(Typetoggle == 0){
            //Item
            performSegue(withIdentifier: "tableSegue", sender: nil)
        }
        else{
            //Container
            performSegue(withIdentifier: "ContainerSegue", sender: nil)
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "tableSegue" {
            let detail = segue.destination as? DetailsViewController
            
            detail?.currentId = ItemsFromDB[selectedRow].itemID
        }
        
        if segue.identifier == "ContainerSegue" {
            let detail = segue.destination as? ContainerDetailsController
            detail?.lookupID = ContainersFromDB[selectedRow].containerID
        }
        
    }
    
    
    
    @IBAction func PrimaryAction(_ sender: Any) {// happens when user presses enter in the searchbox
        print("primaryAction")
        getSearchItems { (ItemStructs) in
            self.ItemsFromDB = ItemStructs
            print(self.ItemsFromDB[0].itemID)
            self.SearchResults.reloadData()
        }
        
    }//end Primary Action
    
    func getAllItems(completion: @escaping ([ItemStruct]) -> ()){
        print("getAllItems started")
        guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/items") else{
            print("bad url")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask =
        session.dataTask(with:url){ [self]
            (data, response, error) in
            
            guard error == nil else{
                print(error?.localizedDescription)
                return
            }
            guard let data = data else{
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try
                    decoder.decode([ItemStruct].self, from: data)
                
                
                
                ItemsFromDB = decodedData
                
                if ItemsFromDB.count == 0{
                    print("no items, dont load them")
                    return
                }
                
                print(ItemsFromDB[0].itemID)
                print(decodedData[0].itemID)
                
                DispatchQueue.main.async{
                    completion(decodedData)
                }
                
            } catch { print(error.localizedDescription)}
            
        }
        dataTask.resume()
        
    }//end GetAllItems
    
    func getSearchItems(completion: @escaping ([ItemStruct]) -> ()){
        guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/Items/search/\(SearchTextBox.text ?? "")") else{
            print("bad url")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask =
        session.dataTask(with:url){ [self]
            (data, response, error) in
            
            guard error == nil else{
                print(error?.localizedDescription)
                return
            }
            guard let data = data else{
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try
                    decoder.decode([ItemStruct].self, from: data)
                
                ItemsFromDB = decodedData
                
                if ItemsFromDB.count == 0{
                    print("no items, dont load them")
                    return
                }
                
                print(ItemsFromDB[0].itemID)
                print(decodedData[0].itemID)
                
                DispatchQueue.main.async{
                    completion(decodedData)
                }
                
            } catch { print(error.localizedDescription)}
            
        }
        dataTask.resume()
        
    }//end GetSearchItems
    
    
    @IBAction func editEnd(_ sender: Any) {
        print("edit end")
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        SearchResults.register(SearchTableViewCell.nib(),forCellReuseIdentifier: SearchTableViewCell.identifier)
        self.navigationItem.rightBarButtonItem = self.editButtonItem
        getAllItems { (ItemStructs) in
            self.ItemsFromDB = ItemStructs
            print(self.ItemsFromDB[0].itemID)
            self.SearchResults.reloadData()
        }
    }
    
    // this line will reload the list after you add an item.(this line can do multiple task as we can see we use it for the viewDiload and the one below
    
    override func viewWillAppear(_ animated: Bool) {
        print("will appear")
        super.viewWillAppear(animated)
        getAllItems { (ItemStructs) in
            self.ItemsFromDB = ItemStructs
            print(self.ItemsFromDB[0].itemID)
            self.SearchResults.reloadData()
        }
        
        GetContainers { (ContainerStruct) in
            self.ContainersFromDB = ContainerStruct
            print(self.ContainersFromDB[0].containerID)
            //self.SearchResults.reloadData()
        }
        
    }//end viewwillappear
    
    @IBAction func ClearButton(_ sender: Any) {
        getAllItems { (ItemStructs) in
            self.ItemsFromDB = ItemStructs
            print(self.ItemsFromDB[0].itemID)
            self.SearchResults.reloadData()
        }
        
        GetContainers { (ContainerStruct) in
            self.ContainersFromDB = ContainerStruct
            print(self.ContainersFromDB[0].containerID)
            //self.SearchResults.reloadData()
        }
        
        SearchTextBox.text = ""
        
    }
    
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    // this line is for delete item
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            self.deleteItems(currentId: self.ItemsFromDB[indexPath.row].itemID)
            self.ItemsFromDB.remove(at: indexPath.row)
            
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    
    func SearchDatabase(Term: String)
    {
        //run the database call to search for the given search term.
        //then update the SearchResults table with whatever entries you get back.
    }
    
    func CreateTableCell(){
        
    }
    
    //this line of code add the delete item
    
    func deleteItems(currentId: String){
        guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/items/\(currentId)")
        else{
            print("Item delete")
            return
        }
        
        let session = URLSession.shared
        
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        
        let dataTask =
        session.dataTask(with:request){
            (data, response, error) in
            
            guard error == nil else{
                print(error?.localizedDescription)
                return
            }
            guard let data = data
            
            else{
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
              //  let decodedData = try
                 //   decoder.decode(ItemStruct.self, from: data)
                
                
                
            } catch { print(error.localizedDescription)}
            
        }
        dataTask.resume()
        
    }//end GetAllItems
    
    func GetContainers(completion: @escaping ([ContainerStruct]) -> ()){
        print("getAllcontainers started")
        guard let url = URL(string: "https://ocu-capstone-01.azurewebsites.net/containers") else{
            print("bad url")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask =
        session.dataTask(with:url){ [self]
            (data, response, error) in
            
            guard error == nil else{
                print(error?.localizedDescription)
                return
            }
            guard let data = data else{
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try
                    decoder.decode([ContainerStruct].self, from: data)
                
                
                
                ContainersFromDB = decodedData
                
                if ContainersFromDB.count == 0{
                    print("no items, dont load them")
                    return
                }
                
                print(ContainersFromDB[0].containerID)
                print(decodedData[0].containerID)
                
                DispatchQueue.main.async{
                    completion(decodedData)
                }
                
            } catch { print(error.localizedDescription)}
            
        }
        dataTask.resume()
        
        
    }//end GetContainers
}



extension SearchViewController: SearchTableViewCellDelegate{
    func didTapButton(with title: String){
        print("\(title)")
        //DetailsViewController.getItemsDescription(<#T##self: DetailsViewController##DetailsViewController#>)
        //tabBarController?.selectedIndex = 2
        
    }
}
